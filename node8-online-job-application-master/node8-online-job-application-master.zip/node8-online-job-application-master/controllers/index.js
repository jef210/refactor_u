var indexController = {
	index: function(req, res) {
		res.render('index');
	}
};

module.exports = indexController;

// this