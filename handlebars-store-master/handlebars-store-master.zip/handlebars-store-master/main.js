$(document).on('ready', function() {
  
  var productContent = $('#product-container').html();

});